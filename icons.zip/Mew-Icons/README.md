Uos-fulldistro-icons [patched by ExposedCat]
